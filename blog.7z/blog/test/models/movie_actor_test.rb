require 'test_helper'

class MovieActorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
