class Movie < ActiveRecord::Base
  mount_uploader :image, ImageUploader
  has_many :movie_actors
  has_many :reviews
  has_many :actors, through: :movie_actors
  accepts_nested_attributes_for :movie_actors, reject_if: :all_blank, allow_destroy: true
end
    