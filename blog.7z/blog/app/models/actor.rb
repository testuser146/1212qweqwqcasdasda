class Actor < ActiveRecord::Base
  has_many :movie_actors
end
