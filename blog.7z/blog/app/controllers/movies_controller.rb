class MoviesController < ApplicationController
  before_action :movie_info, only: [:show, :edit, :update, :destroy]
  def index
    @movies = Movie.all
  end
  def new
    @movie = Movie.new
    @movie.actors.build
  end
  def create
    @movie = Movie.new(movie_params)
    fail
    if @movie.save

      redirect_to movies_path
    else
      
      redirect_to :back
    end
  end
    def show
      @reviews = Review.where(movie_id: @movie.id).order("created_at DESC")

      if @reviews.blank?
        @avg_review = 0
      else
        #@avg_review = @reviews.average(:rating).round(2)
      end
    end
    def edit
    end
    def update 
      if @movie.save(movie_params)
        redirect_to movies_path
      else
        redirect_to :back
      end
    end

    def destroy
      @movie.destroy  
      redirect_to movies_path
    end
  
  private
  def movie_info
    @movie = Movie.find(params[:id])
  end
    def movie_params
      params.require(:movie).permit(:movie_title, :duration, :description, :image, movie_actors_attributes: [:id, :actor_id, :_destroy])
    end
end
