import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ClarityModule } from '@clr/angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './header/header.component';
import { AppComponent } from './app.component';
import { ContentComponent } from './content/content.component';
import {RoutModule} from './rout.module';

import { ReactiveFormsModule, FormsModule  } from '@angular/forms';
import { importExpr } from '@angular/compiler/src/output/output_ast';
import { PremierComponent } from './premier/premier.component';
import { DashbordComponent } from './dashbord/dashbord.component';
@NgModule({
  declarations: [
    AppComponent,
    ContentComponent,
    HeaderComponent,
    PremierComponent,
    DashbordComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ClarityModule,
    FormsModule,
    RoutModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
