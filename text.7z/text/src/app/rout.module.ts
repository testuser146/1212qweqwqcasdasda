import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';
import { PremierComponent } from './premier/premier.component';
import { DashbordComponent } from './dashbord/dashbord.component';
import { ContentComponent } from './content/content.component';
@NgModule({
  imports: [
    RouterModule.forRoot([{path: 'premier', component: PremierComponent},
                          {path: 'dashbord', component: DashbordComponent},
                          {path: 'footer', component: ContentComponent},
                          { path: '',   redirectTo: 'footer', pathMatch: 'full' }]
                          )
  ],
  exports: [RouterModule]
})
export class RoutModule { }
