import { Component, OnInit } from '@angular/core';
import {FormArray , FormGroup , FormBuilder, } from '@angular/forms';
@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  select: any = ['Beneficiary', 'Customer', 'Employee', 'service provider'];
  Beneficiary: boolean;
  arr: boolean;
  checked: boolean;
  contactBlock: boolean;
  myForm: FormGroup;
  constructor(private fb: FormBuilder) {
    this.Beneficiary = false;
    this.arr = false;
    this.checked = false;
  }

  ngOnInit() {
    this.myForm = this.fb.group({
      phone: this.fb.array([]) ,
    });

  }
/**
 *
 *
 * @phoneforms
 */
get phoneForms() {
    return this.myForm.get('phone') as FormArray;
  }
/**
 *
 *
 * @addphone text
 */
addPhone() {
      const phone = this.fb.group({
          code : [],
          number : []
      });
       this.phoneForms.push(phone);
    }
/**
 *
 *
 * @param {*} i
 * @memberof ContentComponentvf
 * @deletephone number field
 */
deletePhone(i) {
      this.phoneForms.removeAt(i);
    }

  public drop(i: string): void {
   // if (i === 'Beneficiary') {
    //   this.Beneficiary = true;
    // } else {
    //   this.Beneficiary = false;
    // }
    this.Beneficiary = i === 'Beneficiary';

  }

  /**
   *
   * @memberof ContentComponent
   */
  public arrow(): void {
    this.arr = !this.arr;
  }
 /**
  *
  *
  * @memberof ContentComponent
  */
 public Checked(): void {
    this.checked = true;
  }
  /**
   *
   *
   * @memberof ContentComponent
   */
  public contact(): void {
    this.contactBlock = !this.contactBlock;
  }

}
