class ChangeRatingColumnTypeInMovies < ActiveRecord::Migration
  def change
  	remove_column :movies, :rating, :string
  	add_column :movies, :rating, :integer, default: 0
  end
end
