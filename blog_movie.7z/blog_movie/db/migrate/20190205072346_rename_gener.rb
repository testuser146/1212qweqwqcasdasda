class RenameGener < ActiveRecord::Migration
  def change
    rename_column :movies, :gener, :genre
  end
end
