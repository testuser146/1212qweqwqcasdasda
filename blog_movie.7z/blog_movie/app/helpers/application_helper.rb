# application helper
module ApplicationHelper
end
