# movies controller
class MoviesController < ApplicationController
  before_action :set_id, only: %i[show edit update destroy]
  before_action :authenticate_user!, except: [:index, :show]
  MOVIES_PER_PAGE = 4
  def index
    @movies = Movie.order(id: :asc).page(params[:page]).per(MOVIES_PER_PAGE)
  end

  def show
    @comments = Comment.where(movie_id: @movie.id).order("created_at DESC")
  end

  def new
    @movie = current_user.movies.build
  end  

  def edit; end

  def create
    @movie = current_user.movies.build(movie_params)
    if @movie.save
      flash[:alert] = 'add successfully redirecting to list page ...'
      redirect_to movies_path
    else
      flash[:danger] = 'missing required fields'
      redirect_to :back
    end
  end

  def add_actors
    @actor = Actor.all
  end

  def update
    if @movie.update(movie_params)
      flash[:alert] = 'add successfully redirecting to list page ...'
      redirect_to movies_path
    else
      flash[:danger] = 'missing required fields'
      redirect_to :back
    end
  end

  def destroy
    @movie.destroy
    redirect_to root_path
  end

  private

  def set_id
    @movie = Movie.friendly.find(params[:id])
  end


  def movie_params
    params.require(:movie).permit(:movie_title, :description, :duration,
                                  :director, :genre, :rating, :image,
                                  actor_ids: [])
  end
end
